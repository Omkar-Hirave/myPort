import { ExternalLink, Github } from "lucide-react";
import { useCardHover } from "@/hooks/use-gsap";
import { motion } from "framer-motion";

interface ProjectCardProps {
  title: string;
  description: string;
  technologies: string[];
  link?: string;
  github?: string;
}

export function ProjectCard({
  title,
  description,
  technologies,
  link,
  github,
}: ProjectCardProps) {
  const hoverProps = useCardHover();

  return (
    <motion.div
      {...hoverProps}
      whileHover={{ y: -8 }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
      className="group relative bg-white dark:bg-slate-800 rounded-2xl p-6 sm:p-8 border border-slate-200 dark:border-slate-700 hover:border-orange-400 dark:hover:border-orange-400 transition-colors cursor-default"
    >
      {/* Gradient accent */}
      <div className="absolute inset-0 bg-gradient-to-br from-orange-50 dark:from-orange-950/30 to-amber-50 dark:to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity -z-10" />

      {/* Header */}
      <h3 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white mb-3 pr-8">
        {title}
      </h3>

      {/* Description */}
      <p className="text-slate-700 dark:text-slate-300 text-sm sm:text-base mb-4 leading-relaxed">
        {description}
      </p>

      {/* Technologies */}
      <div className="mb-4 flex flex-wrap gap-2">
        {technologies.map((tech, idx) => (
          <motion.span
            key={idx}
            whileHover={{ scale: 1.05 }}
            className="inline-block px-3 py-1 rounded-full text-xs sm:text-sm font-medium bg-gradient-to-r from-orange-100 dark:from-orange-900/50 to-amber-100 dark:to-amber-900/50 text-orange-700 dark:text-orange-300"
          >
            {tech}
          </motion.span>
        ))}
      </div>

      {/* Links */}
      {(link || github) && (
        <div className="flex gap-3 pt-4 border-t border-slate-200 dark:border-slate-700">
          {link && (
            <motion.a
              whileHover={{ x: 4 }}
              href={link}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-orange-600 dark:text-orange-400 hover:text-orange-700 dark:hover:text-orange-300 font-medium text-sm transition-colors"
            >
              View Project
              <ExternalLink className="w-4 h-4" />
            </motion.a>
          )}
          {github && (
            <motion.a
              whileHover={{ x: 4 }}
              href={github}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-slate-600 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-300 font-medium text-sm transition-colors"
            >
              Code
              <Github className="w-4 h-4" />
            </motion.a>
          )}
        </div>
      )}
    </motion.div>
  );
}
