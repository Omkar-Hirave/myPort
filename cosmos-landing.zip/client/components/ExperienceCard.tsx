import { ChevronRight } from "lucide-react";
import { useCardHover } from "@/hooks/use-gsap";
import { motion } from "framer-motion";

interface ExperienceCardProps {
  title: string;
  company: string;
  duration: string;
  highlights: string[];
}

export function ExperienceCard({
  title,
  company,
  duration,
  highlights,
}: ExperienceCardProps) {
  const hoverProps = useCardHover();

  return (
    <motion.div
      {...hoverProps}
      whileHover={{ y: -8 }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
      className="group relative bg-white dark:bg-slate-800 rounded-2xl p-6 sm:p-8 border border-slate-200 dark:border-slate-700 hover:border-orange-400 dark:hover:border-orange-400 transition-colors cursor-default"
    >
      {/* Gradient accent */}
      <div className="absolute inset-0 bg-gradient-to-br from-orange-50 dark:from-orange-950/30 to-amber-50 dark:to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity -z-10" />

      {/* Header */}
      <div className="mb-4">
        <h3 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white mb-1">
          {title}
        </h3>
        <p className="text-base sm:text-lg text-orange-600 dark:text-orange-400 font-semibold mb-1">
          {company}
        </p>
        <p className="text-sm text-slate-500 dark:text-slate-400">{duration}</p>
      </div>

      {/* Highlights */}
      <div className="space-y-3">
        {highlights.map((highlight, idx) => (
          <motion.div
            key={idx}
            initial={{ opacity: 0, x: -10 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ delay: idx * 0.1 }}
            className="flex gap-3 items-start"
          >
            <ChevronRight className="w-5 h-5 text-orange-600 dark:text-orange-400 flex-shrink-0 mt-0.5" />
            <p className="text-slate-700 dark:text-slate-300 text-sm sm:text-base leading-relaxed">
              {highlight}
            </p>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
