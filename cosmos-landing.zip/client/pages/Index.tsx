import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ExperienceCard } from "@/components/ExperienceCard";
import { ProjectCard } from "@/components/ProjectCard";
import { BlogCard } from "@/components/BlogCard";
import { AchievementBadges } from "@/components/AchievementBadges";
import { Hero3D } from "@/components/Hero3D";
import { ContactFormModal } from "@/components/ContactFormModal";
import { ArrowRight, Github, Linkedin, Mail, Download, Eye, ChevronDown } from "lucide-react";
import { useRef, useState } from "react";
import { motion } from "framer-motion";
import { useI18n } from "@/contexts/i18n-context";

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.8,
      ease: "easeOut",
    },
  },
};

const blogPosts = [
  {
    title: "Building Scalable React Applications with Component Architecture",
    description: "Deep dive into creating maintainable and performant React components using modern patterns and best practices. Learn composition, hooks, and state management.",
    category: "React",
    date: "Mar 15, 2024",
    readTime: "8 min read",
    link: "https://medium.com",
    views: 2500,
  },
  {
    title: "Master JavaScript Async/Await: From Promises to Modern Patterns",
    description: "Comprehensive guide to understanding asynchronous JavaScript, error handling, and advanced patterns for async operations.",
    category: "JavaScript",
    date: "Mar 10, 2024",
    readTime: "10 min read",
    link: "https://medium.com",
    views: 3200,
  },
  {
    title: "React Hooks Deep Dive: useEffect, useContext, and Custom Hooks",
    description: "Explore the power of React Hooks and learn how to build custom hooks for your application. Advanced patterns included.",
    category: "React",
    date: "Mar 5, 2024",
    readTime: "12 min read",
    link: "https://medium.com",
    views: 4100,
  },
  {
    title: "CSS Grid vs Flexbox: When and How to Use Each",
    description: "Learn the differences between CSS Grid and Flexbox and master when to use each layout system effectively.",
    category: "CSS",
    date: "Feb 28, 2024",
    readTime: "7 min read",
    link: "https://medium.com",
    views: 1800,
  },
  {
    title: "State Management in React: Redux vs Context API vs Zustand",
    description: "Compare different state management solutions and learn when to use Redux, Context API, or newer alternatives.",
    category: "React",
    date: "Feb 20, 2024",
    readTime: "11 min read",
    link: "https://medium.com",
    views: 3500,
  },
  {
    title: "Performance Optimization: Making Your React App Lightning Fast",
    description: "Essential techniques for optimizing React applications including code splitting, memoization, and lazy loading.",
    category: "Performance",
    date: "Feb 12, 2024",
    readTime: "9 min read",
    link: "https://medium.com",
    views: 2800,
  },
];

function ResumeDropdownSection({ t, onContactClick }: { t: (key: string) => string; onContactClick: () => void }) {
  const [isResumeOpen, setIsResumeOpen] = useState(false);

  return (
    <motion.div
      variants={itemVariants}
      className="flex flex-col sm:flex-row gap-4 mb-8 items-start sm:items-center"
    >
      <motion.a
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        href="mailto:your.email@example.com"
        className="inline-flex items-center justify-center gap-2 px-8 py-3 bg-gradient-to-r from-orange-600 to-amber-600 text-white rounded-lg font-semibold hover:shadow-lg transition-all"
      >
        {t("getInTouch")}
        <ArrowRight className="w-5 h-5" />
      </motion.a>
      <motion.a
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        href="#projects"
        className="inline-flex items-center justify-center gap-2 px-8 py-3 border-2 border-slate-300 dark:border-slate-600 text-slate-900 dark:text-white rounded-lg font-semibold hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
      >
        {t("viewMyWork")}
        <ArrowRight className="w-5 h-5" />
      </motion.a>

      {/* Resume Dropdown */}
      <div className="relative">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setIsResumeOpen(!isResumeOpen)}
          className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white rounded-lg font-semibold hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
        >
          <Download className="w-4 h-4" />
          Resume
          <ChevronDown className={`w-4 h-4 transition-transform ${isResumeOpen ? "rotate-180" : ""}`} />
        </motion.button>

        {isResumeOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="absolute top-full mt-2 w-48 bg-white dark:bg-slate-800 rounded-lg shadow-lg border border-slate-200 dark:border-slate-700 overflow-hidden z-50"
          >
            <button
              onClick={() => {
                const link = document.createElement("a");
                link.href = "https://example.com/resume.pdf";
                link.download = "resume.pdf";
                link.click();
                setIsResumeOpen(false);
              }}
              className="flex items-center gap-2 w-full px-4 py-3 text-slate-900 dark:text-white hover:bg-orange-50 dark:hover:bg-orange-900/30 transition-colors text-left"
            >
              <Download className="w-4 h-4 text-orange-600" />
              {t("downloadResume")}
            </button>
            <a
              href="https://example.com/resume"
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => setIsResumeOpen(false)}
              className="flex items-center gap-2 w-full px-4 py-3 text-slate-900 dark:text-white hover:bg-orange-50 dark:hover:bg-orange-900/30 transition-colors text-left border-t border-slate-200 dark:border-slate-700"
            >
              <Eye className="w-4 h-4 text-blue-600" />
              {t("viewResume")}
            </a>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
}

export default function Index() {
  const { t } = useI18n();
  const heroRef = useRef<HTMLDivElement>(null);
  const experienceSectionRef = useRef<HTMLDivElement>(null);
  const skillsSectionRef = useRef<HTMLDivElement>(null);
  const projectsSectionRef = useRef<HTMLDivElement>(null);
  const [isContactOpen, setIsContactOpen] = useState(false);

  return (
    <div className="min-h-screen bg-white dark:bg-slate-900 transition-colors">
      <Header onContactClick={() => setIsContactOpen(true)} />

      {/* Hero Section */}
      <section
        ref={heroRef}
        className="relative overflow-hidden pt-12 pb-32 px-4 sm:px-6 lg:px-8 dark:bg-slate-900"
      >
        {/* Gradient background */}
        <div className="absolute inset-0 -z-10">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-orange-200 dark:bg-orange-600/20 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse" />
          <div className="absolute top-0 right-0 w-96 h-96 bg-amber-200 dark:bg-amber-600/20 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse" />
        </div>

        <div className="max-w-7xl mx-auto">
          {/* Achievement Badges */}
          <AchievementBadges />

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center">
            {/* Content */}
            <motion.div
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              <motion.div
                variants={itemVariants}
                className="inline-block mb-6 px-4 py-2 rounded-full bg-orange-100 dark:bg-orange-900/50 text-orange-700 dark:text-orange-300 text-sm font-semibold"
              >
                {t("welcomePortfolio")}
              </motion.div>

              <motion.h1
                variants={itemVariants}
                className="text-5xl sm:text-6xl font-bold text-slate-900 dark:text-white mb-6 leading-tight"
              >
                {t("heroTitle")}
                <span className="block bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">
                  {t("heroTitleSpan")}
                </span>
              </motion.h1>

              <motion.p
                variants={itemVariants}
                className="text-lg text-slate-600 dark:text-slate-300 mb-8 leading-relaxed max-w-lg"
              >
                {t("heroDescription")}
              </motion.p>

              {/* CTA Buttons with Resume Dropdown */}
              <ResumeDropdownSection t={t} />

              {/* Social Links */}
              <motion.div
                variants={itemVariants}
                className="flex items-center gap-6"
              >
                <span className="text-sm text-slate-600 dark:text-slate-400 font-medium">
                  {t("connectWithMe")}
                </span>
                <div className="flex gap-4">
                  <motion.a
                    whileHover={{ scale: 1.1, y: -2 }}
                    href="https://linkedin.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-orange-600 hover:text-white transition-all"
                    aria-label="LinkedIn"
                  >
                    <Linkedin className="w-5 h-5" />
                  </motion.a>
                  <motion.a
                    whileHover={{ scale: 1.1, y: -2 }}
                    href="https://github.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-900 dark:hover:bg-slate-700 hover:text-white transition-all"
                    aria-label="GitHub"
                  >
                    <Github className="w-5 h-5" />
                  </motion.a>
                  <motion.a
                    whileHover={{ scale: 1.1, y: -2 }}
                    href="mailto:your.email@example.com"
                    className="w-10 h-10 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-orange-600 hover:text-white transition-all"
                    aria-label="Email"
                  >
                    <Mail className="w-5 h-5" />
                  </motion.a>
                </div>
              </motion.div>
            </motion.div>

            {/* 3D Visual Element */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1, delay: 0.3 }}
              className="relative hidden lg:flex justify-center items-center"
            >
              <div className="relative w-full aspect-square">
                <Hero3D />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section id="experience" className="py-20 px-4 sm:px-6 lg:px-8 bg-slate-50 dark:bg-slate-800/50">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="mb-16"
          >
            <h2 className="text-4xl sm:text-5xl font-bold text-slate-900 dark:text-white mb-4">
              {t("experience_title")}
            </h2>
            <p className="text-lg text-slate-600 dark:text-slate-300">
              {t("experience_desc")}
            </p>
          </motion.div>

          <motion.div
            ref={experienceSectionRef}
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-1 gap-8"
          >
            <motion.div variants={itemVariants}>
              <ExperienceCard
                title="Front End Developer"
                company="miniOrange Security Software"
                duration="Sep 2024 – Present"
                highlights={[
                  "Architected a Cloud Security application using a component-driven React architecture with modular design patterns, reducing feature integration effort by 60% and boosting performance by 40%.",
                  "Implemented responsive web design with React-MUI breakpoints, improving cross-device accessibility and reducing UI-related bug reports by 25%.",
                  "Built intuitive auditing dashboards with real-time drill-down analytics, dynamic search filters, and seamless form validation—streamlining audit processes and improving data accuracy across large-scale records.",
                  "Implemented comprehensive unit and integration tests using Jest and React Testing Library, reducing QA testing load by 30%, preventing regressions, and stabilizing production releases.",
                ]}
              />
            </motion.div>

            <motion.div variants={itemVariants}>
              <ExperienceCard
                title="Full Stack Developer"
                company="Flairminds Software"
                duration="Sep 2023 - Aug 2024"
                highlights={[
                  "Designed and developed a carbon emissions tracking app (React + Flask AI APIs) enabling businesses to calculate and report emissions across scopes, leading to an average 22% reduction in carbon footprint.",
                  "Built a full-stack data migration application (React/Node.js) with dynamic mapping, transformation, and smooth transfer capabilities for large multi-database systems, improving data mapping by 35%.",
                  "Constructed a resource management tool using React and Redux Toolkit, enhancing visibility into requests and availability and increasing resource distribution efficiency by 25%.",
                  "E-commerce application: Built a MongoDB-integrated rating system with complex APIs for consumers, retailers, and delivery personnel with Node.js.",
                ]}
              />
            </motion.div>
          </motion.div>

          {/* Additional Achievement */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mt-12 p-8 bg-white dark:bg-slate-700 rounded-2xl border-2 border-orange-200 dark:border-orange-700"
          >
            <p className="text-slate-700 dark:text-slate-200 font-semibold text-lg mb-2">
              {t("keyAchievement")}
            </p>
            <p className="text-slate-600 dark:text-slate-300 text-base">
              {t("keyAchievementText")}
            </p>
          </motion.div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 px-4 sm:px-6 lg:px-8 dark:bg-slate-900">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-16"
          >
            <h2 className="text-4xl sm:text-5xl font-bold text-slate-900 dark:text-white mb-4">
              {t("skills_title")}
            </h2>
            <p className="text-lg text-slate-600 dark:text-slate-300">
              {t("skills_desc")}
            </p>
          </motion.div>

          <motion.div
            ref={skillsSectionRef}
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {[
              {
                title: "Frontend",
                skills: [
                  "React.js",
                  "TypeScript",
                  "HTML",
                  "CSS",
                  "JavaScript (ES6+)",
                  "GraphQL",
                ],
              },
              {
                title: "Backend",
                skills: [
                  "Node.js",
                  "Express.js",
                  "RESTful APIs",
                  "SQL",
                  "MongoDB",
                  "Mongoose ORM",
                ],
              },
              {
                title: "Tools & Frameworks",
                skills: [
                  "Redux Toolkit",
                  "MaterialUI",
                  "Bootstrap",
                  "Git",
                  "Postman",
                  "CursorAI",
                ],
              },
              {
                title: "Specialization",
                skills: [
                  "Cloud Security",
                  "Responsive Design",
                  "Performance Optimization",
                  "Testing & QA",
                ],
              },
              {
                title: "DSA & Problem Solving",
                skills: [
                  "LeetCode",
                  "GeeksforGeeks",
                  "TypeScript",
                  "400+ Problems Solved",
                ],
              },
              {
                title: "Content & Mentorship",
                skills: [
                  "10+ Medium Articles",
                  "100+ Developers Reached",
                  "Team Leadership",
                  "Code Review Expertise",
                ],
              },
            ].map((skillGroup, idx) => (
              <motion.div
                key={idx}
                variants={itemVariants}
                whileHover={{ y: -8 }}
                className="group relative bg-white dark:bg-slate-800 rounded-2xl p-8 border border-slate-200 dark:border-slate-700 hover:border-orange-400 dark:hover:border-orange-400 transition-colors"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-orange-50 dark:from-orange-950/30 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity -z-10" />
                <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-4">
                  {skillGroup.title}
                </h3>
                <div className="flex flex-wrap gap-2">
                  {skillGroup.skills.map((skill, sidx) => (
                    <span
                      key={sidx}
                      className="px-3 py-1.5 rounded-lg bg-orange-100 dark:bg-orange-900/50 text-orange-700 dark:text-orange-300 text-sm font-medium"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 px-4 sm:px-6 lg:px-8 bg-slate-50 dark:bg-slate-800/50">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-16"
          >
            <h2 className="text-4xl sm:text-5xl font-bold text-slate-900 dark:text-white mb-4">
              {t("projects_title")}
            </h2>
            <p className="text-lg text-slate-600 dark:text-slate-300">
              {t("projects_desc")}
            </p>
          </motion.div>

          <motion.div
            ref={projectsSectionRef}
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8"
          >
            {[
              {
                title: "Video Chat App",
                description:
                  "A peer-to-peer video calling platform with low-latency streaming and secure connections. Built with WebRTC for real-time communication and Socket.IO for signaling.",
                technologies: ["React", "Node.js", "WebRTC", "Socket.IO"],
                github: "https://github.com",
              },
              {
                title: "Real-Time Collaborative Design Tool",
                description:
                  "Multi-user canvas with synchronized drawing, zoom/pan navigation, undo/redo history, and conflict resolution. Enables seamless real-time collaboration with consistent state management.",
                technologies: ["React", "Node.js", "WebSockets", "Canvas API"],
                github: "https://github.com",
              },
              {
                title: "Carbon Emissions Tracking App",
                description:
                  "Business application for calculating and reporting emissions across scopes with Flask AI APIs integration. Helped businesses achieve an average 22% reduction in carbon footprint.",
                technologies: ["React", "Flask", "AI APIs", "Analytics"],
                link: "https://example.com",
              },
              {
                title: "Data Migration Application",
                description:
                  "Full-stack solution with dynamic mapping, transformation, and smooth transfer capabilities for large multi-database systems. Improved data mapping efficiency by 35%.",
                technologies: ["React", "Node.js", "MongoDB", "PostgreSQL"],
                github: "https://github.com",
              },
            ].map((project, idx) => (
              <motion.div key={idx} variants={itemVariants}>
                <ProjectCard {...project} />
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Blogs Section */}
      <section id="blogs" className="py-20 px-4 sm:px-6 lg:px-8 dark:bg-slate-900">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-16"
          >
            <h2 className="text-4xl sm:text-5xl font-bold text-slate-900 dark:text-white mb-4">
              {t("blogs_title")}
            </h2>
            <p className="text-lg text-slate-600 dark:text-slate-300">
              {t("blogs_desc")}
            </p>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {blogPosts.map((post, idx) => (
              <motion.div key={idx} variants={itemVariants}>
                <BlogCard {...post} />
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Education Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-slate-50 dark:bg-slate-800/50">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-16"
          >
            <h2 className="text-4xl sm:text-5xl font-bold text-slate-900 dark:text-white mb-4">
              {t("education_title")}
            </h2>
            <p className="text-lg text-slate-600 dark:text-slate-300">
              {t("education_desc")}
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="max-w-2xl"
          >
            <div className="group relative bg-white dark:bg-slate-800 rounded-2xl p-8 border-2 border-slate-200 dark:border-slate-700 hover:border-orange-400 dark:hover:border-orange-400 transition-all hover:shadow-lg">
              <div className="absolute inset-0 bg-gradient-to-br from-orange-50 dark:from-orange-950/30 to-amber-50 dark:to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity -z-10" />

              <div className="flex items-start gap-4 mb-4">
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-orange-600 to-amber-600 flex items-center justify-center flex-shrink-0">
                  <span className="text-white font-bold text-lg">🎓</span>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-slate-900 dark:text-white">
                    MSc Computer Applications
                  </h3>
                  <p className="text-lg text-orange-600 dark:text-orange-400 font-semibold">
                    Fergusson College Pune
                  </p>
                </div>
              </div>

              <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                Advanced study in computer science with focus on software development,
                data structures, and algorithms. Strong foundation in full-stack development
                and system design.
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-orange-600 to-amber-600">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto text-center"
        >
          <h2 className="text-4xl sm:text-5xl font-bold text-white mb-6">
            {t("cta_title")}
          </h2>
          <p className="text-xl text-orange-100 mb-8 leading-relaxed">
            {t("cta_desc")}
          </p>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <motion.a
              variants={itemVariants}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              href="mailto:your.email@example.com"
              className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-white text-orange-600 rounded-lg font-bold text-lg hover:shadow-xl transition-all"
            >
              <Mail className="w-6 h-6" />
              {t("getInTouch")}
            </motion.a>
            <motion.a
              variants={itemVariants}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              href="https://linkedin.com"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 px-8 py-4 border-2 border-white text-white rounded-lg font-bold text-lg hover:bg-white/10 transition-colors"
            >
              <Linkedin className="w-6 h-6" />
              Connect on LinkedIn
            </motion.a>
          </motion.div>
        </motion.div>
      </section>

      <ContactFormModal isOpen={isContactOpen} onClose={() => setIsContactOpen(false)} />
      <Footer />
    </div>
  );
}
